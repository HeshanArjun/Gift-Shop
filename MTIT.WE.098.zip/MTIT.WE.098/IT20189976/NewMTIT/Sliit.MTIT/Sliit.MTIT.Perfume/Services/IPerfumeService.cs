﻿namespace Sliit.MTIT.Perfume.Services
{
    public interface IPerfumeService
    {

        List<Models.Perfume> GetPerfumes();

        Models.Perfume? GetPerfume(int id);

        Models.Perfume? AddPerfume(Models.Perfume perfume);

        Models.Perfume? UpdatePerfume(Models.Perfume perfume);

        bool? DeletePerfume(int id);
    }
}
