﻿namespace Sliit.MTIT.Perfume.Data
{
    public static class PerfumeMockDataService
    {

       public static List<Models.Perfume> Perfumes = new List<Models.Perfume>()
     {
         new Models.Perfume {Id = 1, Name = "Calvin klein ", Description = "light and citrusy in nature", Price = 9800},
         new Models.Perfume {Id = 2, Name = "Victoria's secret", Description = " floral scent", Price = 5200},
         new Models.Perfume {Id = 3, Name = "Versace", Description = "spray on wrist", Price = 12500},
         new Models.Perfume {Id = 4, Name = "Tommy hilfiger", Description = "one signature scent", Price = 10500},
         

     };
    }
}
