﻿namespace Sliit.MTIT.Cake.Services
{
    public interface ICakeService
    {

        List<Models.Cake> GetCakes();

        Models.Cake? GetCake(int id);

        Models.Cake? AddCake(Models.Cake cake);

        Models.Cake? UpdateCake(Models.Cake cake);

        bool? DeleteCake(int id);
    }
}
