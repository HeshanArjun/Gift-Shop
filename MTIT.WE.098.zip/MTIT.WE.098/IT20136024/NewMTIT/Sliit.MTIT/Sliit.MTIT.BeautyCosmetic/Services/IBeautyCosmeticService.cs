﻿namespace Sliit.MTIT.BeautyCosmetic.Services
{
    public interface IBeautyCosmeticService
    {

        List<Models.BeautyCosmetic> GetBeautyCosmetics();

        Models.BeautyCosmetic? GetBeautyCosmetic(int id);

        Models.BeautyCosmetic? AddBeautyCosmetic(Models.BeautyCosmetic beautyCosmetic);

        Models.BeautyCosmetic? UpdateBeautyCosmetic(Models.BeautyCosmetic beautyCosmetic);

        bool? DeleteBeautyCosmetic(int id);
    }
}
