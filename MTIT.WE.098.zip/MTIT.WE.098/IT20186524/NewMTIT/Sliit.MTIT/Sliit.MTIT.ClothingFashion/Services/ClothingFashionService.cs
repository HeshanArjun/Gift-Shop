﻿using Sliit.MTIT.ClothingFashion.Data;
using Sliit.MTIT.ClothingFashion.Models;

namespace Sliit.MTIT.ClothingFashion.Services
{
    public class ClothingFashionService : IClothingFashionService
    {
        public List<Models.ClothingFashion> GetClothingFashions()

        {
            return ClothingFashionMockDataService.ClothingFashions;

        }

        public Models.ClothingFashion? GetClothingFashion(int id)
        {
            return ClothingFashionMockDataService.ClothingFashions.FirstOrDefault(x => x.Id == id);
        }

        public Models.ClothingFashion? AddClothingFashion(Models.ClothingFashion clothingFashion)
        {
            ClothingFashionMockDataService.ClothingFashions.Add(clothingFashion);
            return clothingFashion;
        }

        public Models.ClothingFashion? UpdateClothingFashion(Models.ClothingFashion clothingFashion)
        {
            Models.ClothingFashion selectedClothingFashion = ClothingFashionMockDataService.ClothingFashions.FirstOrDefault(x => x.Id == clothingFashion.Id);
            if (selectedClothingFashion != null)
            {
                selectedClothingFashion.Description = clothingFashion.Description;
                selectedClothingFashion.Price = clothingFashion.Price;
                selectedClothingFashion.Name = clothingFashion.Name;
                return selectedClothingFashion;
            }

            return selectedClothingFashion;
        }

        public bool? DeleteClothingFashion(int id)
        {
            Models.ClothingFashion selectedClothingFashion = ClothingFashionMockDataService.ClothingFashions.FirstOrDefault(x => x.Id == id);
            if (selectedClothingFashion != null)
            {
                ClothingFashionMockDataService.ClothingFashions.Remove(selectedClothingFashion);
                return true;
            }

            return false;
        }
    }


}