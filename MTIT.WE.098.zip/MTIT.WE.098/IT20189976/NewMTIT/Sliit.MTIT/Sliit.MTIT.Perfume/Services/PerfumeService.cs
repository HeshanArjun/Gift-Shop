﻿using Sliit.MTIT.Perfume.Data;
using Sliit.MTIT.Perfume.Models;

namespace Sliit.MTIT.Perfume.Services
{
    public class PerfumeService : IPerfumeService
    {
        public List<Models.Perfume> GetPerfumes()

        {
            return PerfumeMockDataService.Perfumes;

        }

        public Models.Perfume? GetPerfume(int id)
        {
            return PerfumeMockDataService.Perfumes.FirstOrDefault(x => x.Id == id);
        }

        public Models.Perfume? AddPerfume(Models.Perfume perfume)
        {
            PerfumeMockDataService.Perfumes.Add(perfume);
            return perfume;
        }

        public Models.Perfume? UpdatePerfume(Models.Perfume perfume)
        {
            Models.Perfume selectedPerfume = PerfumeMockDataService.Perfumes.FirstOrDefault(x => x.Id == perfume.Id);
            if (selectedPerfume != null)
            {
                selectedPerfume.Description = perfume.Description;
                selectedPerfume.Price = perfume.Price;
                selectedPerfume.Name = perfume.Name;
                return selectedPerfume;
            }

            return selectedPerfume;
        }

        public bool? DeletePerfume(int id)
        {
            Models.Perfume selectedPerfume = PerfumeMockDataService.Perfumes.FirstOrDefault(x => x.Id == id);
            if (selectedPerfume != null)
            {
                PerfumeMockDataService.Perfumes.Remove(selectedPerfume);
                return true;
            }

            return false;
        }
    }


}