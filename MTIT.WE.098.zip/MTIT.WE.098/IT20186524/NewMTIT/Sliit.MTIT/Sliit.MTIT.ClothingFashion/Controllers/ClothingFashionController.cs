﻿using Intercom.Core;
using Microsoft.AspNetCore.Mvc;
using Sliit.MTIT.ClothingFashion.Services;
using System.Reflection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sliit.MTIT.ClothingFashion.Models;





public class ClothingFashionController : ControllerBase
{

    private readonly IClothingFashionService _clothingFashionService;

    public ClothingFashionController(IClothingFashionService clothingFashionService)
    {
        _clothingFashionService = clothingFashionService ?? throw new ArgumentNullException(nameof(clothingFashionService));
    }


    /// <summary>
    /// Get all ClothingFashion
    /// </summary>
    /// <returns>return the list of ClothingFashion</returns>
    [HttpGet]

    public IActionResult Get()
    {
        return Ok(_clothingFashionService.GetClothingFashions());
    }


    /// <summary>
    /// Get ClothingFashion by ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet("{id}")]

    public IActionResult Get(int id)
    {
        return _clothingFashionService.GetClothingFashion(id) != null ? Ok(_clothingFashionService.GetClothingFashion(id)) : NoContent();
    }


    /// <summary>
    /// Add ClothingFashion
    /// </summary>
    /// <param name="ClothingFashion"></param>
    /// <returns></returns>
    [HttpPost("SaveClothingFashion")]

    public IActionResult Post([FromBody] ClothingFashion clothingFashion)
    {
        return Ok(_clothingFashionService.AddClothingFashion(clothingFashion));
    }


    /// <summary>
    /// Update the ClothingFashion
    /// </summary>
    /// <param name="clothingFashion"></param>
    /// <returns></returns>
    [HttpPut("UpdateClothingFashion")]

    public IActionResult Put([FromBody] ClothingFashion clothingFashion)
    {
        return Ok(_clothingFashionService.UpdateClothingFashion(clothingFashion));
    }


    /// <summary>
    /// Delete the ClothingFashion with the passed ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpDelete("{id}")]

    public IActionResult Delete(int id)
    {
        var result = _clothingFashionService.DeleteClothingFashion(id);

        return result.HasValue & result == true ? Ok($"Clothing and Fashion with ID :{id} got delete successfully.")
             : BadRequest($"Unable to delete the Clothing and Fashion with ID : {id}.");
    }
}
