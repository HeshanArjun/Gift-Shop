﻿using Sliit.MTIT.BeautyCosmetic.Data;
using Sliit.MTIT.BeautyCosmetic.Models;

namespace Sliit.MTIT.BeautyCosmetic.Services
{
    public class BeautyCosmeticService : IBeautyCosmeticService
    {
        public List<Models.BeautyCosmetic> GetBeautyCosmetics()

        {
            return BeautyCosmeticMockDataService.BeautyCosmetics;

        }

        public Models.BeautyCosmetic? GetBeautyCosmetic(int id)
        {
            return BeautyCosmeticMockDataService.BeautyCosmetics.FirstOrDefault(x => x.Id == id);
        }

        public Models.BeautyCosmetic? AddBeautyCosmetic(Models.BeautyCosmetic beautyCosmetic)
        {
            BeautyCosmeticMockDataService.BeautyCosmetics.Add(beautyCosmetic);
            return beautyCosmetic;
        }

       public Models.BeautyCosmetic? UpdateBeautyCosmetic(Models.BeautyCosmetic beautyCosmetic)
        {
            Models.BeautyCosmetic selectedBeautyCosmetic = BeautyCosmeticMockDataService.BeautyCosmetics.FirstOrDefault(x => x.Id == beautyCosmetic.Id);
            if (selectedBeautyCosmetic != null)
            {
                selectedBeautyCosmetic.Description = beautyCosmetic.Description;
                selectedBeautyCosmetic.Price = beautyCosmetic.Price;
                selectedBeautyCosmetic.Name = beautyCosmetic.Name;
                return selectedBeautyCosmetic;
            }

            return selectedBeautyCosmetic;
        }

        public bool? DeleteBeautyCosmetic(int id)
        {
            Models.BeautyCosmetic selectedBeautyCosmetic = BeautyCosmeticMockDataService.BeautyCosmetics.FirstOrDefault(x => x.Id == id);
            if (selectedBeautyCosmetic != null)
            {
                BeautyCosmeticMockDataService.BeautyCosmetics.Remove(selectedBeautyCosmetic);
                return true;
            }

            return false;
        }
    }


}