﻿using Sliit.MTIT.Cake.Data;
using Sliit.MTIT.Cake.Models;

namespace Sliit.MTIT.Cake.Services
{
    public class CakeService : ICakeService
    {
        public List<Models.Cake> GetCakes()

        {
            return CakeMockDataService.Cakes;

        }

        public Models.Cake? GetCake(int id)
        {
            return CakeMockDataService.Cakes.FirstOrDefault(x => x.Id == id);
        }

        public Models.Cake? AddCake(Models.Cake cake)
        {
            CakeMockDataService.Cakes.Add(cake);
            return cake;
        }

        public Models.Cake? UpdateCake(Models.Cake cake)
        {
            Models.Cake selectedCake = CakeMockDataService.Cakes.FirstOrDefault(x => x.Id == cake.Id);
            if (selectedCake != null)
            {
                selectedCake.Description = cake.Description;
                selectedCake.Price = cake.Price;
                selectedCake.Name = cake.Name;
                return selectedCake;
            }

            return selectedCake;
        }

        public bool? DeleteCake(int id)
        {
            Models.Cake selectedCake = CakeMockDataService.Cakes.FirstOrDefault(x => x.Id == id);
            if (selectedCake != null)
            {
                CakeMockDataService.Cakes.Remove(selectedCake);
                return true;
            }

            return false;
        }
    }


}