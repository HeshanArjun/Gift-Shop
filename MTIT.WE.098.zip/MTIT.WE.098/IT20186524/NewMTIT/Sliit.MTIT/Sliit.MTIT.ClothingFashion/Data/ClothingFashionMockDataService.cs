﻿namespace Sliit.MTIT.ClothingFashion.Data
{
    public static class ClothingFashionMockDataService
    {

        public static List<Models.ClothingFashion> ClothingFashions = new List<Models.ClothingFashion>()
     {
         new Models.ClothingFashion {Id = 1, Name = "Handbags ", Description = "Pure leather handbag", Price = 5000},
         new Models.ClothingFashion {Id = 2, Name = "Men's Accessories", Description = " Leather belts", Price = 2200},
         new Models.ClothingFashion {Id = 3, Name = "Women's Accessories", Description = "Jewellery", Price = 2100},
         new Models.ClothingFashion {Id = 4, Name = "Bathik Items", Description = "Hand maded bathik", Price = 2300},
         

     };
    }
}
