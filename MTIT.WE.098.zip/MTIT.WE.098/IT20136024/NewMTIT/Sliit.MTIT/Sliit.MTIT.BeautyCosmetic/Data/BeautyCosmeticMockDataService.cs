﻿namespace Sliit.MTIT.BeautyCosmetic.Data
{
    public static class BeautyCosmeticMockDataService
    {

       public static List<Models.BeautyCosmetic> BeautyCosmetics = new List<Models.BeautyCosmetic>()
     {
         new Models.BeautyCosmetic {Id = 1, Name = "Skin Care ", Description = "NIVEA Face Cream ", Price = 2800},
         new Models.BeautyCosmetic {Id = 2, Name = "Bath & Body", Description = " SPA CEYLON Almond Body Soap Bar", Price = 2200},
         new Models.BeautyCosmetic {Id = 3, Name = "Men's Grooming", Description = "Black Men Body Spray ", Price = 3500},
         new Models.BeautyCosmetic {Id = 4, Name = "Makeup Kit", Description = "HUDA BEAUTY Lipstickt", Price = 1350},
         

     };
    }
}
