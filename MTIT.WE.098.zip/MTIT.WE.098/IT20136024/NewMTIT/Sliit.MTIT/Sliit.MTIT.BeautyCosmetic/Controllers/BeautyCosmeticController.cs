﻿using Intercom.Core;
using Microsoft.AspNetCore.Mvc;
using Sliit.MTIT.BeautyCosmetic.Services;
using System.Reflection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sliit.MTIT.BeautyCosmetic.Models;





public class BeautyCosmeticController : ControllerBase
{

    private readonly IBeautyCosmeticService _beautyCosmeticService;

    public BeautyCosmeticController(IBeautyCosmeticService beautyCosmeticService)
    {
        _beautyCosmeticService = beautyCosmeticService ?? throw new ArgumentNullException(nameof(beautyCosmeticService));
    }


    /// <summary>
    /// Get all beauty Cosmetics
    /// </summary>
    /// <returns>return the list of beautyCosmetics</returns>
    [HttpGet]

    public IActionResult Get()
    {
        return Ok(_beautyCosmeticService.GetBeautyCosmetics());
    }


    /// <summary>
    /// Get Beauty Cosmetics by ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet("{id}")]

    public IActionResult Get(int id)
    {
        return _beautyCosmeticService.GetBeautyCosmetic(id) != null ? Ok(_beautyCosmeticService.GetBeautyCosmetic(id)) : NoContent();
    }


    /// <summary>
    /// Add beauty Cosmetics
    /// </summary>
    /// <param name="BeautyCosmetic"></param>
    /// <returns></returns>
    [HttpPost("SaveBeautyCosmetic")]

    public IActionResult Post([FromBody] BeautyCosmetic beautyCosmetic)
    {
        return Ok(_beautyCosmeticService.AddBeautyCosmetic(beautyCosmetic));
    }


    /// <summary>
    /// Update the beautyCosmetic
    /// </summary>
    /// <param name="BeautyCosmetic"></param>
    /// <returns></returns>
    [HttpPut("UpdateBeautyCosmetic")]

    public IActionResult Put([FromBody] BeautyCosmetic beautyCosmetic)
    {
        return Ok(_beautyCosmeticService.UpdateBeautyCosmetic(beautyCosmetic));
    }


    /// <summary>
    /// Delete the beautyCosmetic with the passed ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpDelete("{id}")]

    public IActionResult Delete(int id)
    {
        var result = _beautyCosmeticService.DeleteBeautyCosmetic(id);

        return result.HasValue & result == true ? Ok($"Beauty and Cosmetic with ID :{id} got delete successfully.")
             : BadRequest($"Unable to delete the beauty and Cosmetic with ID : {id}.");
    }
}
