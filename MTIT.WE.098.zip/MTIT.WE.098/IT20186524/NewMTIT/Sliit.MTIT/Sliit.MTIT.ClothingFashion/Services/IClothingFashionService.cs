﻿namespace Sliit.MTIT.ClothingFashion.Services
{
    public interface IClothingFashionService
    {

        List<Models.ClothingFashion> GetClothingFashions();

        Models.ClothingFashion? GetClothingFashion(int id);

        Models.ClothingFashion? AddClothingFashion(Models.ClothingFashion clothingFashion);

        Models.ClothingFashion? UpdateClothingFashion(Models.ClothingFashion clothingFashion);

        bool? DeleteClothingFashion(int id);
    }
}
