﻿using Intercom.Core;
using Microsoft.AspNetCore.Mvc;
using Sliit.MTIT.Perfume.Services;
using System.Reflection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sliit.MTIT.Perfume.Models;





public class PerfumeController : ControllerBase
{

    private readonly IPerfumeService _perfumeService;

    public PerfumeController(IPerfumeService perfumeService)
    {
        _perfumeService = perfumeService ?? throw new ArgumentNullException(nameof(perfumeService));
    }


    /// <summary>
    /// Get all Perfume
    /// </summary>
    /// <returns>return the list of Perfume</returns>
    [HttpGet]

    public IActionResult Get()
    {
        return Ok(_perfumeService.GetPerfumes());
    }


    /// <summary>
    /// Get Perfume by ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet("{id}")]

    public IActionResult Get(int id)
    {
        return _perfumeService.GetPerfume(id) != null ? Ok(_perfumeService.GetPerfume(id)) : NoContent();
    }


    /// <summary>
    /// Add Perfume
    /// </summary>
    /// <param name="Perfume"></param>
    /// <returns></returns>
    [HttpPost("SavePerfume")]

    public IActionResult Post([FromBody] Perfume perfume)
    {
        return Ok(_perfumeService.AddPerfume(perfume));
    }


    /// <summary>
    /// Update the Perfume
    /// </summary>
    /// <param name="Perfume"></param>
    /// <returns></returns>
    [HttpPut("UpdatePerfume")]

    public IActionResult Put([FromBody] Perfume perfume)
    {
        return Ok(_perfumeService.UpdatePerfume(perfume));
    }


    /// <summary>
    /// Delete the Perfume with the passed ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpDelete("{id}")]

    public IActionResult Delete(int id)
    {
        var result = _perfumeService.DeletePerfume(id);

        return result.HasValue & result == true ? Ok($"Perfume with ID :{id} got delete successfully.")
             : BadRequest($"Unable to delete the Perfume with ID : {id}.");
    }
}
