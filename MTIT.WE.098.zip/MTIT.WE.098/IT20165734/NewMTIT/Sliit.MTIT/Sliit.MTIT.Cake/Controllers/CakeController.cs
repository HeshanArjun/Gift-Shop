﻿using Intercom.Core;
using Microsoft.AspNetCore.Mvc;
using Sliit.MTIT.Cake.Services;
using System.Reflection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sliit.MTIT.Cake.Models;





public class CakeController : ControllerBase
{

    private readonly ICakeService _cakeService;

    public CakeController(ICakeService cakeService)
    {
        _cakeService =cakeService ?? throw new ArgumentNullException(nameof(cakeService));
    }


    /// <summary>
    /// Get all Cakes
    /// </summary>
    /// <returns>return the list of Cakes</returns>
    [HttpGet]

    public IActionResult Get()
    {
        return Ok(_cakeService.GetCakes());
    }


    /// <summary>
    /// Get Cake by ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet("{id}")]

    public IActionResult Get(int id)
    {
        return _cakeService.GetCake(id) != null ? Ok(_cakeService.GetCake(id)) : NoContent();
    }


    /// <summary>
    /// Add cake
    /// </summary>
    /// <param name="cake"></param>
    /// <returns></returns>
    [HttpPost("SaveCake")]

    public IActionResult Post([FromBody] Cake cake)
    {
        return Ok(_cakeService.AddCake(cake));
    }


    /// <summary>
    /// Update the cake
    /// </summary>
    /// <param name="cake"></param>
    /// <returns></returns>
    [HttpPut("UpdateCake")]

    public IActionResult Put([FromBody] Cake cake)
    {
        return Ok(_cakeService.UpdateCake(cake));
    }


    /// <summary>
    /// Delete the cake with the passed ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpDelete("{id}")]

    public IActionResult Delete(int id)
    {
        var result = _cakeService.DeleteCake(id);

        return result.HasValue & result == true ? Ok($"cake with ID :{id} got delete successfully.")
             : BadRequest($"Unable to delete the cake with ID : {id}.");
    }
}
