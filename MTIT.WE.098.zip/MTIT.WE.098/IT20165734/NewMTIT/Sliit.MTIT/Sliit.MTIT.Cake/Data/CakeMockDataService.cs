﻿namespace Sliit.MTIT.Cake.Data
{
    public static class CakeMockDataService
    {

        public static List<Models.Cake> Cakes = new List<Models.Cake>()
     {
         new Models.Cake {Id = 1, Name = "Chocolate cake ", Description = "Lava cake", Price = 2500},
         new Models.Cake {Id = 2, Name = "Butter cake", Description = "Made buy butter", Price = 2200},
         new Models.Cake {Id = 3, Name = "Cup cake", Description = "Small and sweet", Price = 2100},
         new Models.Cake {Id = 4, Name = "Red velvet cake", Description = "Sweet flavoured", Price = 2300},
         

     };
    }
}
